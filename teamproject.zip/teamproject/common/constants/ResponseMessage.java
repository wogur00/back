package com.example.back404.teamproject.common.constants;

public class ResponseMessage {
    // 성공 메시지
    public static final String SUCCESS = "Success";

    // 강의 승인 및 생성 메시지

    // 조회 성공 메시지
    // public static final String

    // 과목 상태 변경 메시지

    // '승인 대기' 상태의 과목만 거절

    // 과목 등록 거절 메시지

    // 과목을 등록 할 수 없습니다

    // 선생님을 찾을 수 없습니다.

    // '승인 대기' 상태의 과목만 처리할 수 있습니다.

    // 존재 여부 관련 메시지
   public static final String NOT_EXISTS_SUBJECT = "Subject not found";

}