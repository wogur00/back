package com.example.back404.teamproject.service;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.subjects.request.SubjectRequestDto;
import com.example.back404.teamproject.dto.subjects.request.SubjectUpdateRequestDto;
import com.example.back404.teamproject.dto.subjects.response.SubjectDetailDto;
import com.example.back404.teamproject.dto.teacher.request.TeacherUpdateRequestDto;
import com.example.back404.teamproject.dto.teacher.response.TeacherResponseDto;

public interface TeacherService {
    
    // 교사 정보 조회 (마이페이지)
    ResponseDto<TeacherResponseDto> getMyInfo();
    
    // 교사 정보 수정 (마이페이지)
    ResponseDto<TeacherResponseDto> updateMyInfo(TeacherUpdateRequestDto requestDto);
    
    // 과목 등록
    ResponseDto<SubjectDetailDto> createSubject(SubjectRequestDto requestDto);
    
    // 과목 수정
    ResponseDto<SubjectDetailDto> updateSubject(String subjectId, SubjectUpdateRequestDto requestDto);
    
    // 과목 삭제
    ResponseDto<String> deleteSubject(String subjectId);
}