package com.example.back404.teamproject.service.implementations;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.auth.FindIdRequestDto;
import com.example.back404.teamproject.dto.auth.FindPasswordRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignInRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignUpRequestDto;
import com.example.back404.teamproject.dto.auth.UserSignInResponseDto;
import com.example.back404.teamproject.entity.School;
import com.example.back404.teamproject.entity.Student;
import com.example.back404.teamproject.entity.Teacher;
import com.example.back404.teamproject.provider.JwtProvider;
import com.example.back404.teamproject.repository.SchoolRepository;
import com.example.back404.teamproject.repository.StudentRepository;
import com.example.back404.teamproject.repository.TeacherRepository;
import com.example.back404.teamproject.service.TeacherAuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class TeacherAuthServiceImpl implements TeacherAuthService {
    
    private final TeacherRepository teacherRepository;
    private final SchoolRepository schoolRepository;
    private final StudentRepository studentRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;
    
    // 교사 회원가입
    @Override
    @Transactional
    public ResponseDto<String> registerTeacher(TeacherSignUpRequestDto requestDto) {
        try {
            // 중복 체크
            if (teacherRepository.existsByTeacherUsername(requestDto.getTeacherUsername())) {
                return ResponseDto.setFailed("이미 사용 중인 사용자명입니다.");
            }
            
            if (teacherRepository.existsByTeacherEmail(requestDto.getTeacherEmail())) {
                return ResponseDto.setFailed("이미 사용 중인 이메일입니다.");
            }
            
            // 학교 코드 확인
            School school = schoolRepository.findBySchoolCode(Integer.parseInt(requestDto.getSchoolCode()))
                    .orElseThrow(() -> new RuntimeException("존재하지 않는 학교 코드입니다."));
            
            Teacher teacher = Teacher.builder()
                    .teacherId(requestDto.getTeacherId())
                    .school(school)
                    .teacherUsername(requestDto.getTeacherUsername())
                    .teacherPassword(passwordEncoder.encode(requestDto.getTeacherPassword()))
                    .teacherName(requestDto.getTeacherName())
                    .teacherEmail(requestDto.getTeacherEmail())
                    .teacherPhoneNumber(requestDto.getTeacherPhoneNumber())
                    .teacherSubject(requestDto.getTeacherSubject())
                    .build();
            
            teacherRepository.save(teacher);
            
            return ResponseDto.setSuccess("교사 회원가입이 완료되었습니다.", null);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("회원가입에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 교사 로그인
    @Override
    public ResponseDto<UserSignInResponseDto> loginTeacher(TeacherSignInRequestDto requestDto) {
        try {
            Optional<Teacher> optionalTeacher = teacherRepository.findByTeacherUsername(requestDto.getTeacherUsername());
            
            if (optionalTeacher.isEmpty()) {
                return ResponseDto.setFailed("존재하지 않는 사용자명입니다.");
            }
            
            Teacher teacher = optionalTeacher.get();
            
            if (!passwordEncoder.matches(requestDto.getTeacherPassword(), teacher.getTeacherPassword())) {
                return ResponseDto.setFailed("비밀번호가 일치하지 않습니다.");
            }
            
            String token = jwtProvider.generateJwtToken(teacher.getTeacherEmail(), Set.of("TEACHER"));
            UserSignInResponseDto responseDto = new UserSignInResponseDto(token, 3600);
            
            return ResponseDto.setSuccess("로그인 성공", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("로그인에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 아이디 찾기
    @Override
    public ResponseDto<String> findId(FindIdRequestDto requestDto) {
        try {
            String foundId = null;
            
            if ("TEACHER".equals(requestDto.getUserType())) {
                Optional<Teacher> teacher = teacherRepository.findByTeacherNameAndTeacherEmail(
                        requestDto.getName(), requestDto.getEmail());
                if (teacher.isPresent()) {
                    foundId = teacher.get().getTeacherUsername();
                }
            } else if ("STUDENT".equals(requestDto.getUserType())) {
                Optional<Student> student = studentRepository.findByNameAndEmail(
                        requestDto.getName(), requestDto.getEmail());
                if (student.isPresent()) {
                    foundId = student.get().getUsername();
                }
            }
            
            if (foundId != null) {
                return ResponseDto.setSuccess("아이디를 찾았습니다.", foundId);
            } else {
                return ResponseDto.setFailed("해당 정보로 등록된 계정을 찾을 수 없습니다.");
            }
            
        } catch (Exception e) {
            return ResponseDto.setFailed("아이디 찾기에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 비밀번호 찾기 (임시 비밀번호 발급)
    @Override
    public ResponseDto<String> findPassword(FindPasswordRequestDto requestDto) {
        try {
            String tempPassword = generateTempPassword();
            boolean found = false;
            
            if ("TEACHER".equals(requestDto.getUserType())) {
                Optional<Teacher> teacher = teacherRepository.findByTeacherUsernameAndTeacherEmail(
                        requestDto.getUsername(), requestDto.getEmail());
                if (teacher.isPresent()) {
                    Teacher t = teacher.get();
                    t.changePassword(passwordEncoder.encode(tempPassword));
                    teacherRepository.save(t);
                    found = true;
                }
            } else if ("STUDENT".equals(requestDto.getUserType())) {
                Optional<Student> student = studentRepository.findByUsernameAndEmail(
                        requestDto.getUsername(), requestDto.getEmail());
                if (student.isPresent()) {
                    Student s = student.get();
                    s.changePassword(passwordEncoder.encode(tempPassword));
                    studentRepository.save(s);
                    found = true;
                }
            }
            
            if (found) {
                return ResponseDto.setSuccess("임시 비밀번호가 발급되었습니다.", tempPassword);
            } else {
                return ResponseDto.setFailed("해당 정보로 등록된 계정을 찾을 수 없습니다.");
            }
            
        } catch (Exception e) {
            return ResponseDto.setFailed("비밀번호 찾기에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 임시 비밀번호 생성
    private String generateTempPassword() {
        return "temp" + System.currentTimeMillis();
    }
}