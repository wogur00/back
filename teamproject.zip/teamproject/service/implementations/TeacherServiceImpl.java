package com.example.back404.teamproject.service.implementations;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.common.constants.enums.SubjectStatus;
import com.example.back404.teamproject.dto.subjects.request.SubjectRequestDto;
import com.example.back404.teamproject.dto.subjects.request.SubjectUpdateRequestDto;
import com.example.back404.teamproject.dto.subjects.response.SubjectDetailDto;
import com.example.back404.teamproject.dto.teacher.request.TeacherUpdateRequestDto;
import com.example.back404.teamproject.dto.teacher.response.TeacherResponseDto;
import com.example.back404.teamproject.entity.Subject;
import com.example.back404.teamproject.entity.Teacher;
import com.example.back404.teamproject.repository.SubjectRepository;
import com.example.back404.teamproject.repository.TeacherRepository;
import com.example.back404.teamproject.service.TeacherService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class TeacherServiceImpl implements TeacherService {
    
    private final TeacherRepository teacherRepository;
    private final SubjectRepository subjectRepository;
    
    // 현재 로그인한 교사의 이메일 가져오기
    private String getCurrentUserEmail() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }
    
    // 현재 로그인한 교사 정보 가져오기
    private Teacher getCurrentTeacher() {
        String email = getCurrentUserEmail();
        return teacherRepository.findByTeacherEmail(email)
                .orElseThrow(() -> new RuntimeException("존재하지 않는 교사입니다."));
    }
    
    // 교사 정보 조회 (마이페이지)
    @Override
    @Transactional(readOnly = true)
    public ResponseDto<TeacherResponseDto> getMyInfo() {
        try {
            Teacher teacher = getCurrentTeacher();
            
            TeacherResponseDto responseDto = TeacherResponseDto.builder()
                    .teacherId(teacher.getTeacherId())
                    .teacherUsername(teacher.getTeacherUsername())
                    .teacherName(teacher.getTeacherName())
                    .teacherEmail(teacher.getTeacherEmail())
                    .teacherPhoneNumber(teacher.getTeacherPhoneNumber())
                    .teacherSubject(teacher.getTeacherSubject())
                    .teacherStatus(teacher.getTeacherStatus())
                    .createdAt(teacher.getCreatedAt())
                    .updatedAt(teacher.getUpdatedAt())
                    .build();
            
            return ResponseDto.setSuccess("교사 정보 조회 성공", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("교사 정보 조회에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 교사 정보 수정 (마이페이지)
    @Override
    public ResponseDto<TeacherResponseDto> updateMyInfo(TeacherUpdateRequestDto requestDto) {
        try {
            Teacher teacher = getCurrentTeacher();
            
            teacher.updateInfo(
                    requestDto.getTeacherEmail(),
                    requestDto.getTeacherPhoneNumber(),
                    requestDto.getTeacherSubject()
            );
            
            teacherRepository.save(teacher);
            
            TeacherResponseDto responseDto = TeacherResponseDto.builder()
                    .teacherId(teacher.getTeacherId())
                    .teacherUsername(teacher.getTeacherUsername())
                    .teacherName(teacher.getTeacherName())
                    .teacherEmail(teacher.getTeacherEmail())
                    .teacherPhoneNumber(teacher.getTeacherPhoneNumber())
                    .teacherSubject(teacher.getTeacherSubject())
                    .teacherStatus(teacher.getTeacherStatus())
                    .createdAt(teacher.getCreatedAt())
                    .updatedAt(teacher.getUpdatedAt())
                    .build();
            
            return ResponseDto.setSuccess("교사 정보 수정 성공", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("교사 정보 수정에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 과목 등록
    @Override
    public ResponseDto<SubjectDetailDto> createSubject(SubjectRequestDto requestDto) {
        try {
            Teacher teacher = getCurrentTeacher();
            
            // 과목 ID 중복 체크
            if (subjectRepository.existsById(requestDto.getSubjectId())) {
                return ResponseDto.setFailed("이미 존재하는 과목 ID입니다.");
            }
            
            Subject subject = Subject.builder()
                    .subjectId(requestDto.getSubjectId())
                    .school(teacher.getSchool())
                    .subjectName(requestDto.getSubjectName())
                    .grade(requestDto.getGrade())
                    .semester(requestDto.getSemester())
                    .affiliation(requestDto.getAffiliation())
                    .status(SubjectStatus.pending)
                    .maxEnrollment(requestDto.getMaxEnrollment())
                    .build();
            
            subjectRepository.save(subject);
            
            SubjectDetailDto responseDto = SubjectDetailDto.builder()
                    .subjectId(subject.getSubjectId())
                    .schoolId(subject.getSchool().getSchoolId())
                    .subjectName(subject.getSubjectName())
                    .grade(subject.getGrade())
                    .semester(subject.getSemester())
                    .affiliation(subject.getAffiliation())
                    .status(subject.getStatus())
                    .maxEnrollment(subject.getMaxEnrollment())
                    .build();
            
            return ResponseDto.setSuccess("과목 등록이 완료되었습니다.", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("과목 등록에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 과목 수정
    @Override
    public ResponseDto<SubjectDetailDto> updateSubject(String subjectId, SubjectUpdateRequestDto requestDto) {
        try {
            Subject subject = subjectRepository.findById(subjectId)
                    .orElseThrow(() -> new EntityNotFoundException("과목을 찾을 수 없습니다."));
            
            subject.updateSubjectInfo(
                    requestDto.getSubjectName(),
                    requestDto.getGrade(),
                    requestDto.getSemester(),
                    requestDto.getAffiliation(),
                    requestDto.getMaxEnrollment()
            );
            
            subjectRepository.save(subject);
            
            SubjectDetailDto responseDto = SubjectDetailDto.builder()
                    .subjectId(subject.getSubjectId())
                    .schoolId(subject.getSchool().getSchoolId())
                    .subjectName(subject.getSubjectName())
                    .grade(subject.getGrade())
                    .semester(subject.getSemester())
                    .affiliation(subject.getAffiliation())
                    .status(subject.getStatus())
                    .maxEnrollment(subject.getMaxEnrollment())
                    .build();
            
            return ResponseDto.setSuccess("과목 수정이 완료되었습니다.", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("과목 수정에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 과목 삭제
    @Override
    public ResponseDto<String> deleteSubject(String subjectId) {
        try {
            Subject subject = subjectRepository.findById(subjectId)
                    .orElseThrow(() -> new EntityNotFoundException("과목을 찾을 수 없습니다."));
            
            subjectRepository.delete(subject);
            
            return ResponseDto.setSuccess("과목 삭제가 완료되었습니다.", null);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("과목 삭제에 실패했습니다: " + e.getMessage());
        }
    }
}