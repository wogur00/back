package com.example.back404.teamproject.service.implementations;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.notice.request.NoticeRequestDto;
import com.example.back404.teamproject.dto.notice.request.NoticeUpdateRequestDto;
import com.example.back404.teamproject.dto.notice.response.NoticeListDto;
import com.example.back404.teamproject.dto.notice.response.NoticeResponseDto;
import com.example.back404.teamproject.entity.Notice;
import com.example.back404.teamproject.entity.School;
import com.example.back404.teamproject.repository.NoticeRepository;
import com.example.back404.teamproject.repository.SchoolRepository;
import com.example.back404.teamproject.service.NoticeService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class NoticeServiceImpl implements NoticeService {
    
    private final NoticeRepository noticeRepository;
    private final SchoolRepository schoolRepository;
    
    // 현재 로그인한 사용자의 이메일 가져오기
    private String getCurrentUserEmail() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }
    
    // 현재 로그인한 학교 관리자의 학교 정보 가져오기
    private School getCurrentSchool() {
        String email = getCurrentUserEmail();
        return schoolRepository.findBySchoolAdminEmail(email)
                .orElseThrow(() -> new RuntimeException("존재하지 않는 관리자입니다."));
    }
    
    // 공지사항 등록
    @Override
    public ResponseDto<NoticeResponseDto> createNotice(NoticeRequestDto requestDto) {
        try {
            School school = getCurrentSchool();
            
            Notice notice = Notice.builder()
                    .school(school)
                    .noticeTitle(requestDto.getNoticeTitle())
                    .noticeContent(requestDto.getNoticeContent())
                    .noticeTargetAudience(requestDto.getNoticeTargetAudience())
                    .noticeStartDate(requestDto.getNoticeStartDate())
                    .noticeEndDate(requestDto.getNoticeEndDate())
                    .build();
            
            noticeRepository.save(notice);
            
            NoticeResponseDto responseDto = NoticeResponseDto.builder()
                    .noticeId(notice.getNoticeId())
                    .noticeTitle(notice.getNoticeTitle())
                    .noticeContent(notice.getNoticeContent())
                    .noticeTargetAudience(notice.getNoticeTargetAudience())
                    .noticeStartDate(notice.getNoticeStartDate())
                    .noticeEndDate(notice.getNoticeEndDate())
                    .createdAt(notice.getCreatedAt())
                    .updatedAt(notice.getUpdatedAt())
                    .build();
            
            return ResponseDto.setSuccess("공지사항이 성공적으로 등록되었습니다.", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("공지사항 등록에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 공지사항 목록 조회 (카테고리별)
    @Override
    @Transactional(readOnly = true)
    public ResponseDto<List<NoticeListDto>> getNoticesByCategory(String category) {
        try {
            School school = getCurrentSchool();
            List<Notice> notices;
            
            if (category == null || category.equals("all")) {
                notices = noticeRepository.findBySchoolSchoolIdOrderByCreatedAtDesc(school.getSchoolId());
            } else {
                notices = noticeRepository.findBySchoolAndCategory(school.getSchoolId(), category);
            }
            
            List<NoticeListDto> noticeListDtos = notices.stream()
                    .map(notice -> NoticeListDto.builder()
                            .noticeId(notice.getNoticeId())
                            .noticeTitle(notice.getNoticeTitle())
                            .noticeTargetAudience(notice.getNoticeTargetAudience())
                            .noticeStartDate(notice.getNoticeStartDate())
                            .noticeEndDate(notice.getNoticeEndDate())
                            .createdAt(notice.getCreatedAt())
                            .build())
                    .collect(Collectors.toList());
            
            return ResponseDto.setSuccess("공지사항 목록 조회 성공", noticeListDtos);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("공지사항 목록 조회에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 공지사항 상세 조회
    @Override
    @Transactional(readOnly = true)
    public ResponseDto<NoticeResponseDto> getNoticeById(Long noticeId) {
        try {
            Notice notice = noticeRepository.findById(noticeId)
                    .orElseThrow(() -> new EntityNotFoundException("공지사항을 찾을 수 없습니다."));
            
            NoticeResponseDto responseDto = NoticeResponseDto.builder()
                    .noticeId(notice.getNoticeId())
                    .noticeTitle(notice.getNoticeTitle())
                    .noticeContent(notice.getNoticeContent())
                    .noticeTargetAudience(notice.getNoticeTargetAudience())
                    .noticeStartDate(notice.getNoticeStartDate())
                    .noticeEndDate(notice.getNoticeEndDate())
                    .createdAt(notice.getCreatedAt())
                    .updatedAt(notice.getUpdatedAt())
                    .build();
            
            return ResponseDto.setSuccess("공지사항 상세 조회 성공", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("공지사항 조회에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 공지사항 수정
    @Override
    public ResponseDto<NoticeResponseDto> updateNotice(Long noticeId, NoticeUpdateRequestDto requestDto) {
        try {
            Notice notice = noticeRepository.findById(noticeId)
                    .orElseThrow(() -> new EntityNotFoundException("공지사항을 찾을 수 없습니다."));
            
            // 공지사항 정보 업데이트
            notice.updateNotice(
                    requestDto.getNoticeTitle(),
                    requestDto.getNoticeContent(),
                    requestDto.getNoticeTargetAudience(),
                    requestDto.getNoticeStartDate(),
                    requestDto.getNoticeEndDate()
            );
            
            noticeRepository.save(notice);
            
            NoticeResponseDto responseDto = NoticeResponseDto.builder()
                    .noticeId(notice.getNoticeId())
                    .noticeTitle(notice.getNoticeTitle())
                    .noticeContent(notice.getNoticeContent())
                    .noticeTargetAudience(notice.getNoticeTargetAudience())
                    .noticeStartDate(notice.getNoticeStartDate())
                    .noticeEndDate(notice.getNoticeEndDate())
                    .createdAt(notice.getCreatedAt())
                    .updatedAt(notice.getUpdatedAt())
                    .build();
            
            return ResponseDto.setSuccess("공지사항이 성공적으로 수정되었습니다.", responseDto);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("공지사항 수정에 실패했습니다: " + e.getMessage());
        }
    }
    
    // 공지사항 삭제
    @Override
    public ResponseDto<String> deleteNotice(Long noticeId) {
        try {
            Notice notice = noticeRepository.findById(noticeId)
                    .orElseThrow(() -> new EntityNotFoundException("공지사항을 찾을 수 없습니다."));
            
            noticeRepository.delete(notice);
            
            return ResponseDto.setSuccess("공지사항이 성공적으로 삭제되었습니다.", null);
            
        } catch (Exception e) {
            return ResponseDto.setFailed("공지사항 삭제에 실패했습니다: " + e.getMessage());
        }
    }
}