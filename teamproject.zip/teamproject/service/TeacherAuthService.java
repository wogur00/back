package com.example.back404.teamproject.service;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.auth.FindIdRequestDto;
import com.example.back404.teamproject.dto.auth.FindPasswordRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignInRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignUpRequestDto;
import com.example.back404.teamproject.dto.auth.UserSignInResponseDto;

public interface TeacherAuthService {
    
    // 교사 회원가입
    ResponseDto<String> registerTeacher(TeacherSignUpRequestDto requestDto);
    
    // 교사 로그인
    ResponseDto<UserSignInResponseDto> loginTeacher(TeacherSignInRequestDto requestDto);
    
    // 아이디 찾기 (교사/학생 공통)
    ResponseDto<String> findId(FindIdRequestDto requestDto);
    
    // 비밀번호 찾기 (교사/학생 공통)
    ResponseDto<String> findPassword(FindPasswordRequestDto requestDto);
}