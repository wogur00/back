package com.example.back404.teamproject.service;

import com.example.back404.teamproject.dto.ResponseDto;
import com.example.back404.teamproject.dto.auth.SchoolApplicationRequestDto;

public interface SchoolApplicationService {
    ResponseDto<Long> register(SchoolApplicationRequestDto requestDto);
    ResponseDto<?> getById(Long id);

    ResponseDto<String> approve(Long id);
}