package com.example.back404.teamproject.service;

import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.notice.request.NoticeRequestDto;
import com.example.back404.teamproject.dto.notice.request.NoticeUpdateRequestDto;
import com.example.back404.teamproject.dto.notice.response.NoticeListDto;
import com.example.back404.teamproject.dto.notice.response.NoticeResponseDto;

import java.util.List;

public interface NoticeService {
    
    // 공지사항 등록
    ResponseDto<NoticeResponseDto> createNotice(NoticeRequestDto requestDto);
    
    // 공지사항 목록 조회 (카테고리별)
    ResponseDto<List<NoticeListDto>> getNoticesByCategory(String category);
    
    // 공지사항 상세 조회
    ResponseDto<NoticeResponseDto> getNoticeById(Long noticeId);
    
    // 공지사항 수정
    ResponseDto<NoticeResponseDto> updateNotice(Long noticeId, NoticeUpdateRequestDto requestDto);
    
    // 공지사항 삭제
    ResponseDto<String> deleteNotice(Long noticeId);
}