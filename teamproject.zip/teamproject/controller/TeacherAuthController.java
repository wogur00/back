package com.example.back404.teamproject.controller;

import com.example.back404.teamproject.common.constants.ApiMappingPattern;
import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.auth.FindIdRequestDto;
import com.example.back404.teamproject.dto.auth.FindPasswordRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignInRequestDto;
import com.example.back404.teamproject.dto.auth.TeacherSignUpRequestDto;
import com.example.back404.teamproject.dto.auth.UserSignInResponseDto;
import com.example.back404.teamproject.service.TeacherAuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(ApiMappingPattern.AUTH_API)
@RequiredArgsConstructor
public class TeacherAuthController {
    
    private final TeacherAuthService teacherAuthService;
    
    // 교사 회원가입
    @PostMapping("/teachers/signup")
    public ResponseEntity<ResponseDto<String>> teacherSignup(
            @Valid @RequestBody TeacherSignUpRequestDto requestDto) {
        ResponseDto<String> response = teacherAuthService.registerTeacher(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 교사 로그인
    @PostMapping("/teachers/login")
    public ResponseEntity<ResponseDto<UserSignInResponseDto>> teacherLogin(
            @Valid @RequestBody TeacherSignInRequestDto requestDto) {
        ResponseDto<UserSignInResponseDto> response = teacherAuthService.loginTeacher(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 아이디 찾기 (교사/학생 공통)
    @PostMapping("/find-id")
    public ResponseEntity<ResponseDto<String>> findId(
            @Valid @RequestBody FindIdRequestDto requestDto) {
        ResponseDto<String> response = teacherAuthService.findId(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 비밀번호 찾기 (교사/학생 공통)
    @PostMapping("/find-password")
    public ResponseEntity<ResponseDto<String>> findPassword(
            @Valid @RequestBody FindPasswordRequestDto requestDto) {
        ResponseDto<String> response = teacherAuthService.findPassword(requestDto);
        return ResponseEntity.ok(response);
    }
}