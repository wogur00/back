package com.example.back404.teamproject.controller;

import com.example.back404.teamproject.common.constants.ApiMappingPattern;
import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.subjects.request.SubjectRequestDto;
import com.example.back404.teamproject.dto.subjects.request.SubjectUpdateRequestDto;
import com.example.back404.teamproject.dto.subjects.response.SubjectDetailDto;
import com.example.back404.teamproject.dto.teacher.request.TeacherUpdateRequestDto;
import com.example.back404.teamproject.dto.teacher.response.TeacherResponseDto;
import com.example.back404.teamproject.service.TeacherService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(ApiMappingPattern.TEACHER_API)
@RequiredArgsConstructor
public class TeacherController {
    
    private final TeacherService teacherService;
    
    // 교사 정보 조회 (마이페이지)
    @GetMapping("/me")
    public ResponseEntity<ResponseDto<TeacherResponseDto>> getMyInfo() {
        ResponseDto<TeacherResponseDto> response = teacherService.getMyInfo();
        return ResponseEntity.ok(response);
    }
    
    // 교사 정보 수정 (마이페이지)
    @PutMapping("/me")
    public ResponseEntity<ResponseDto<TeacherResponseDto>> updateMyInfo(
            @Valid @RequestBody TeacherUpdateRequestDto requestDto) {
        ResponseDto<TeacherResponseDto> response = teacherService.updateMyInfo(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 과목 등록
    @PostMapping("/subjects")
    public ResponseEntity<ResponseDto<SubjectDetailDto>> createSubject(
            @Valid @RequestBody SubjectRequestDto requestDto) {
        ResponseDto<SubjectDetailDto> response = teacherService.createSubject(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 과목 수정
    @PutMapping("/subjects/{subjectId}")
    public ResponseEntity<ResponseDto<SubjectDetailDto>> updateSubject(
            @PathVariable String subjectId,
            @Valid @RequestBody SubjectUpdateRequestDto requestDto) {
        ResponseDto<SubjectDetailDto> response = teacherService.updateSubject(subjectId, requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 과목 삭제
    @DeleteMapping("/subjects/{subjectId}")
    public ResponseEntity<ResponseDto<String>> deleteSubject(
            @PathVariable String subjectId) {
        ResponseDto<String> response = teacherService.deleteSubject(subjectId);
        return ResponseEntity.ok(response);
    }
}