package com.example.back404.teamproject.controller;

import com.example.back404.teamproject.common.constants.ApiMappingPattern;
import com.example.back404.teamproject.common.constants.ResponseDto;
import com.example.back404.teamproject.dto.notice.request.NoticeRequestDto;
import com.example.back404.teamproject.dto.notice.request.NoticeUpdateRequestDto;
import com.example.back404.teamproject.dto.notice.response.NoticeListDto;
import com.example.back404.teamproject.dto.notice.response.NoticeResponseDto;
import com.example.back404.teamproject.service.NoticeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(ApiMappingPattern.NOTICE_API)
@RequiredArgsConstructor
public class NoticeController {
    
    private final NoticeService noticeService;
    
    // 공지사항 등록
    @PostMapping
    public ResponseEntity<ResponseDto<NoticeResponseDto>> createNotice(
            @Valid @RequestBody NoticeRequestDto requestDto) {
        ResponseDto<NoticeResponseDto> response = noticeService.createNotice(requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 공지사항 목록 조회 (카테고리별)
    @GetMapping
    public ResponseEntity<ResponseDto<List<NoticeListDto>>> getNoticesByCategory(
            @RequestParam(value = "category", defaultValue = "all") String category) {
        ResponseDto<List<NoticeListDto>> response = noticeService.getNoticesByCategory(category);
        return ResponseEntity.ok(response);
    }
    
    // 공지사항 상세 조회
    @GetMapping("/{noticeId}")
    public ResponseEntity<ResponseDto<NoticeResponseDto>> getNoticeById(
            @PathVariable Long noticeId) {
        ResponseDto<NoticeResponseDto> response = noticeService.getNoticeById(noticeId);
        return ResponseEntity.ok(response);
    }
    
    // 공지사항 수정
    @PutMapping("/{noticeId}")
    public ResponseEntity<ResponseDto<NoticeResponseDto>> updateNotice(
            @PathVariable Long noticeId,
            @Valid @RequestBody NoticeUpdateRequestDto requestDto) {
        ResponseDto<NoticeResponseDto> response = noticeService.updateNotice(noticeId, requestDto);
        return ResponseEntity.ok(response);
    }
    
    // 공지사항 삭제
    @DeleteMapping("/{noticeId}")
    public ResponseEntity<ResponseDto<String>> deleteNotice(
            @PathVariable Long noticeId) {
        ResponseDto<String> response = noticeService.deleteNotice(noticeId);
        return ResponseEntity.ok(response);
    }
}