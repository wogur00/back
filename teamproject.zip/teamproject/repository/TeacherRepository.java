package com.example.back404.teamproject.repository;

import com.example.back404.teamproject.entity.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, String> {
    
    // 사용자명 중복 체크
    boolean existsByTeacherUsername(String teacherUsername);
    
    // 이메일 중복 체크
    boolean existsByTeacherEmail(String teacherEmail);
    
    // 사용자명으로 교사 조회
    Optional<Teacher> findByTeacherUsername(String teacherUsername);
    
    // 이메일로 교사 조회
    Optional<Teacher> findByTeacherEmail(String teacherEmail);
    
    // 이름과 이메일로 교사 조회 (아이디 찾기용)
    Optional<Teacher> findByTeacherNameAndTeacherEmail(String teacherName, String teacherEmail);
    
    // 사용자명과 이메일로 교사 조회 (비밀번호 찾기용)
    Optional<Teacher> findByTeacherUsernameAndTeacherEmail(String teacherUsername, String teacherEmail);
}