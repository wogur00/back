package com.example.back404.teamproject.repository;

import com.example.back404.teamproject.common.constants.enums.NoticeTargetAudience;
import com.example.back404.teamproject.entity.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface NoticeRepository extends JpaRepository<Notice, Long> {
    
    // 학교별 공지사항 전체 조회 (Long 타입으로 수정)
    List<Notice> findBySchoolSchoolIdOrderByCreatedAtDesc(Long schoolId);
    
    // 카테고리별 공지사항 조회 (Long 타입으로 수정)
    @Query("SELECT n FROM Notice n WHERE n.school.schoolId = :schoolId " +
           "AND (:category = 'all' OR " +
           "(:category = 'school' AND n.noticeTargetAudience IN ('ALL', 'STUDENT', 'TEACHER')) OR " +
           "(:category = 'system' AND n.noticeTargetAudience = 'ALL') OR " +
           "(:category = 'registration' AND n.noticeTargetAudience IN ('ALL', 'STUDENT'))) " +
           "ORDER BY n.createdAt DESC")
    List<Notice> findBySchoolAndCategory(@Param("schoolId") Long schoolId, @Param("category") String category);
    
    // 대상별 공지사항 조회 (Long 타입으로 수정)
    List<Notice> findBySchoolSchoolIdAndNoticeTargetAudienceOrderByCreatedAtDesc(Long schoolId, NoticeTargetAudience targetAudience);
    
    // 현재 유효한 공지사항 조회 (Long 타입으로 수정)
    @Query("SELECT n FROM Notice n WHERE n.school.schoolId = :schoolId " +
           "AND n.noticeStartDate <= :today AND n.noticeEndDate >= :today " +
           "ORDER BY n.createdAt DESC")
    List<Notice> findActiveNotices(@Param("schoolId") Long schoolId, @Param("today") LocalDate today);
}