package com.example.back404.teamproject.repository;

import com.example.back404.teamproject.common.constants.enums.SubjectAffiliation;
import com.example.back404.teamproject.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, String> {
    
    // 계열별 과목 조회
    List<Subject> findByAffiliation(SubjectAffiliation affiliation);
    
    // 과목 ID 존재 여부 확인
    boolean existsById(String subjectId);
    
    // 학교별 과목 조회 (Long 타입으로 수정)
    List<Subject> findBySchoolSchoolId(Long schoolId);
    
    // 학교별 + 계열별 과목 조회 (Long 타입으로 수정)
    List<Subject> findBySchoolSchoolIdAndAffiliation(Long schoolId, SubjectAffiliation affiliation);
}