package com.example.back404.teamproject.repository;
import com.example.back404.teamproject.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {
    
    // 사용자명 중복 체크
    boolean existsByUsername(String username);
    
    // 학번 중복 체크
    boolean existsByStudentNumber(String studentNumber);
    
    // 이메일 중복 체크
    boolean existsByEmail(String email);
    
    // 사용자명으로 학생 조회
    Optional<Student> findByUsername(String username);
    
    // 이메일로 학생 조회
    Optional<Student> findByEmail(String email);
    
    // 이름과 이메일로 학생 조회 (아이디 찾기용)
    Optional<Student> findByNameAndEmail(String name, String email);
    
    // 사용자명과 이메일로 학생 조회 (비밀번호 찾기용)
    Optional<Student> findByUsernameAndEmail(String username, String email);
    
    // 학교별 학생 조회 (Long → String으로 수정)
    Optional<Student> findBySchoolSchoolIdAndUsername(Long schoolId, String username);
}