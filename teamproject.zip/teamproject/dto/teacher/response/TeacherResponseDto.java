package com.example.back404.teamproject.dto.teacher.response;

import com.example.back404.teamproject.common.constants.enums.TeacherStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TeacherResponseDto {
    
    private String teacherId;
    private String teacherUsername;
    private String teacherName;
    private String teacherEmail;
    private String teacherPhoneNumber;
    private String teacherSubject;
    private TeacherStatus teacherStatus;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}