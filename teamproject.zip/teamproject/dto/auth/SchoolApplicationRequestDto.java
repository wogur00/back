package com.example.back404.teamproject.dto.auth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SchoolApplicationRequestDto {
    private String schoolName;
    private String schoolAddress;
    private String schoolContactNumber;
    private String schoolAdminName;
    private String schoolAdminPhoneNumber;
    private String schoolAdminEmail;
}