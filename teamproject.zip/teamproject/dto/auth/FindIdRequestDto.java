package com.example.back404.teamproject.dto.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FindIdRequestDto {
    
    @NotBlank(message = "이름은 필수입니다.")
    private String name;
    
    @Email(message = "이메일 형식이 올바르지 않습니다.")
    @NotBlank(message = "이메일은 필수입니다.")
    private String email;
    
    @NotBlank(message = "사용자 유형은 필수입니다. (TEACHER, STUDENT)")
    private String userType;
}