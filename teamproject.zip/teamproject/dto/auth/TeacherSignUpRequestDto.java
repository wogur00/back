package com.example.back404.teamproject.dto.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeacherSignUpRequestDto {
    
    @NotBlank(message = "교사 ID는 필수입니다.")
    private String teacherId;
    
    @NotBlank(message = "사용자명은 필수입니다.")
    private String teacherUsername;
    
    @NotBlank(message = "비밀번호는 필수입니다.")
    private String teacherPassword;
    
    @NotBlank(message = "교사 이름은 필수입니다.")
    private String teacherName;
    
    @Email(message = "이메일 형식이 올바르지 않습니다.")
    @NotBlank(message = "이메일은 필수입니다.")
    private String teacherEmail;
    
    @NotBlank(message = "전화번호는 필수입니다.")
    private String teacherPhoneNumber;
    
    @NotBlank(message = "담당 과목은 필수입니다.")
    private String teacherSubject;
    
    @NotBlank(message = "학교 코드는 필수입니다.")
    private String schoolCode;
}