package com.example.back404.teamproject.dto.auth;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class UserSignInResponseDto {

    private String token;    // JWT 토큰
    private int exprTime;    // 토큰 만료 시간 (초 단위)
}