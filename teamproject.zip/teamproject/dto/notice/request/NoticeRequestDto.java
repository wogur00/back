package com.example.back404.teamproject.dto.notice.request;

import com.example.back404.teamproject.common.constants.enums.NoticeTargetAudience;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class NoticeRequestDto {
    
    @NotBlank(message = "공지사항 제목은 필수입니다.")
    private String noticeTitle;
    
    @NotBlank(message = "공지사항 내용은 필수입니다.")
    private String noticeContent;
    
    @NotNull(message = "대상 그룹은 필수입니다.")
    private NoticeTargetAudience noticeTargetAudience;
    
    @NotNull(message = "시작 날짜는 필수입니다.")
    private LocalDate noticeStartDate;
    
    @NotNull(message = "종료 날짜는 필수입니다.")
    private LocalDate noticeEndDate;
}