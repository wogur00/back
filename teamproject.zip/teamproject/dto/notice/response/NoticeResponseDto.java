package com.example.back404.teamproject.dto.notice.response;

import com.example.back404.teamproject.common.constants.enums.NoticeTargetAudience;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NoticeResponseDto {
    
    private Long noticeId;
    private String noticeTitle;
    private String noticeContent;
    private NoticeTargetAudience noticeTargetAudience;
    private LocalDate noticeStartDate;
    private LocalDate noticeEndDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}