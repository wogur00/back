package com.example.back404.teamproject.entity;
import com.example.back404.teamproject.common.constants.enums.TeacherStatus;
import com.example.back404.teamproject.entity.datatime.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "teacher")
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Builder
public class Teacher extends BaseTimeEntity {
    
    @Id
    @Column(name = "teacher_id")
    private String teacherId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;
    
    @Column(name = "teacher_username", unique = true, nullable = false)
    private String teacherUsername;
    
    @Column(name = "teacher_password", nullable = false)
    private String teacherPassword;
    
    @Column(name = "teacher_name", nullable = false)
    private String teacherName;
    
    @Column(name = "teacher_email", unique = true, nullable = false)
    private String teacherEmail;
    
    @Column(name = "teacher_phone_number", nullable = false)
    private String teacherPhoneNumber;
    
    @Column(name = "teacher_subject", nullable = false)
    private String teacherSubject;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "teacher_status", nullable = false)
    private TeacherStatus teacherStatus = TeacherStatus.PENDING;
    
    // 교사 정보 수정
    public void updateInfo(String email, String phoneNumber, String subject) {
        this.teacherEmail = email;
        this.teacherPhoneNumber = phoneNumber;
        this.teacherSubject = subject;
    }
    
    // 비밀번호 변경
    public void changePassword(String newPassword) {
        this.teacherPassword = newPassword;
    }
    
    // 교사 승인
    public void approve() {
        if (this.teacherStatus != TeacherStatus.PENDING) {
            throw new IllegalStateException("승인 대기 상태의 교사만 승인할 수 있습니다.");
        }
        this.teacherStatus = TeacherStatus.APPROVED;
    }
    
    // 휴직 처리
    public void takeLeave() {
        if (this.teacherStatus != TeacherStatus.APPROVED) {
            throw new IllegalStateException("승인된 교사만 휴직할 수 있습니다.");
        }
        this.teacherStatus = TeacherStatus.ON_LEAVE;
    }
    
    // 복직 처리
    public void reinstate() {
        if (this.teacherStatus != TeacherStatus.ON_LEAVE) {
            throw new IllegalStateException("휴직 중인 교사만 복직할 수 있습니다.");
        }
        this.teacherStatus = TeacherStatus.APPROVED;
    }
    
    // 퇴직 처리
    public void retire() {
        this.teacherStatus = TeacherStatus.RETIRED;
    }
    
    // ===== 추가된 메서드들 (LectureServiceImpl 에러 해결용) =====
    
    // Getter 메서드 (기존 getName() 메서드 유지)
    public String getName() {
        return this.teacherName;
    }
    
    // LectureServiceImpl에서 호출하는 메서드들 추가
    public String getTeacherName() {
        return this.teacherName;
    }
    
    // Lecture Entity에서 Teacher를 참조할 때 사용할 수 있는 메서드
    public Teacher getTeacher() {
        return this;
    }
}