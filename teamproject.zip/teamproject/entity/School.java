package com.example.back404.teamproject.entity;

import com.example.back404.teamproject.entity.datatime.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "school")
@Getter
@Setter  // 추가
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Builder
public class School extends BaseTimeEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 수정
    @Column(name = "school_id")
    private Long schoolId;  // String -> Long으로 변경
    
    @Column(name = "school_code", nullable = false, unique = true)
    private Integer schoolCode;
    
    @Column(name = "school_name", nullable = false)
    private String schoolName;
    
    @Column(name = "school_address", nullable = false)
    private String schoolAddress;
    
    @Column(name = "school_contact_number", nullable = false)
    private String schoolContactNumber;
    
    @Column(name = "school_password", nullable = false)
    private String schoolPassword;
    
    @Column(name = "school_admin_name", nullable = false)
    private String schoolAdminName;
    
    @Column(name = "school_admin_phone_number", nullable = false)
    private String schoolAdminPhoneNumber;
    
    @Column(name = "school_admin_email", nullable = false)
    private String schoolAdminEmail;
    
    @Column(name = "application_started_day", nullable = false)
    private LocalDate applicationStartedDay;
    
    @Column(name = "application_limited_day", nullable = false)
    private LocalDate applicationLimitedDay;
    
    @Builder.Default
    @Column(name = "is_email_verified", nullable = false)
    private Boolean isEmailVerified = false;  // 누락된 컬럼 추가
    
    @Builder.Default
    @Column(name = "school_code_verification_key", length = 50)
    private String schoolCodeVerificationKey = "";
    
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    // === 비즈니스 로직 === //
    public void updateSchoolInfo(String address, String contactNumber, String adminName, String adminPhoneNumber, String adminEmail) {
        this.schoolAddress = address;
        this.schoolContactNumber = contactNumber;
        this.schoolAdminName = adminName;
        this.schoolAdminPhoneNumber = adminPhoneNumber;
        this.schoolAdminEmail = adminEmail;
    }
    
    public void changePassword(String newPassword) {
        this.schoolPassword = newPassword;
    }
    
    public void updateApplicationPeriod(LocalDate startDate, LocalDate limitedDate) {
        this.applicationStartedDay = startDate;
        this.applicationLimitedDay = limitedDate;
    }
    
    public void verifyEmail() {
        this.isEmailVerified = true;
    }
    
    public void softDelete() {
        this.deletedAt = LocalDateTime.now();
    }
    
    public boolean isDeleted() {
        return this.deletedAt != null;
    }
    
    public void updateSchoolMainInfo(String name, String address, String contactNumber) {
        this.schoolName = name;
        this.schoolAddress = address;
        this.schoolContactNumber = contactNumber;
    }
}