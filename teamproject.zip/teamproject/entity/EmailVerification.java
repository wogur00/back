package com.example.back404.teamproject.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;


import java.time.LocalDateTime;

@Entity
@Table(name = "email_verification")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Email
    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String token;

    // 인증 여부
    @Column(name = "is_verified", nullable = false)
    private Boolean isVerified = false;

    @Column(name = "expiration_time", nullable = false)
    private LocalDateTime expirationTime;
}