package com.example.back404.teamproject.entity;
import com.example.back404.teamproject.common.constants.enums.CourseRegistrationStatus;
import com.example.back404.teamproject.entity.datatime.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "course_registration")
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Builder
public class CourseRegistration extends BaseTimeEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registration_id")
    private Long registrationId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lecture_id", nullable = false)
    private Lecture lecture;
    
    @Column(name = "course_registration_academic_year", nullable = false)
    private Integer academicYear;
    
    @Column(name = "course_registration_semester", nullable = false)
    private String semester;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "course_registration_approval_status", nullable = false)
    private CourseRegistrationStatus approvalStatus = CourseRegistrationStatus.PENDING;
    
    // 수강신청 승인
    public void approve() {
        this.approvalStatus = CourseRegistrationStatus.APPROVED;
    }
    
    // 수강신청 거절
    public void reject() {
        this.approvalStatus = CourseRegistrationStatus.REJECTED;
    }
    
    // ===== 추가된 비즈니스 메서드들 =====
    
    // 승인 상태 확인
    public boolean isApproved() {
        return this.approvalStatus == CourseRegistrationStatus.APPROVED;
    }
    
    // 대기 상태 확인
    public boolean isPending() {
        return this.approvalStatus == CourseRegistrationStatus.PENDING;
    }
    
    // 거절 상태 확인
    public boolean isRejected() {
        return this.approvalStatus == CourseRegistrationStatus.REJECTED;
    }
    
    // 수강신청 정보 업데이트
    public void updateRegistrationInfo(Integer academicYear, String semester) {
        this.academicYear = academicYear;
        this.semester = semester;
    }
}