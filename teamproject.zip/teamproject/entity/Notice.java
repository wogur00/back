package com.example.back404.teamproject.entity;
import com.example.back404.teamproject.common.constants.enums.NoticeTargetAudience;
import com.example.back404.teamproject.entity.datatime.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "notice")
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Builder
public class Notice extends BaseTimeEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notice_id")
    private Long noticeId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;
    
    @Column(name = "notice_title", nullable = false)
    private String noticeTitle;
    
    @Column(name = "notice_content", nullable = false, columnDefinition = "TEXT")
    private String noticeContent;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "notice_target_audience", nullable = false)
    private NoticeTargetAudience noticeTargetAudience;
    
    @Column(name = "notice_start_date", nullable = false)
    private LocalDate noticeStartDate;
    
    @Column(name = "notice_end_date", nullable = false)
    private LocalDate noticeEndDate;
    
    // ===== 추가된 비즈니스 메서드들 =====
    
    // 공지사항 내용 업데이트
    public void updateNotice(String title, String content, NoticeTargetAudience targetAudience, 
                           LocalDate startDate, LocalDate endDate) {
        this.noticeTitle = title;
        this.noticeContent = content;
        this.noticeTargetAudience = targetAudience;
        this.noticeStartDate = startDate;
        this.noticeEndDate = endDate;
    }
    
    // 공지사항 기간 확인
    public boolean isActive(LocalDate currentDate) {
        return !currentDate.isBefore(noticeStartDate) && !currentDate.isAfter(noticeEndDate);
    }
    
    // 특정 대상에게 보여줄 공지사항인지 확인
    public boolean isTargetAudience(NoticeTargetAudience audience) {
        return this.noticeTargetAudience == NoticeTargetAudience.ALL || this.noticeTargetAudience == audience;
    }
}
